import React from 'react';

function App() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Lisan+</h1>
      <p>Welcome to your Arabic immersion app.</p>
    </div>
  );
}

export default App;
